console.log("my script is triggered");

//Implement a function called changeImage to 
//1. change the src of the element with id 'mainpicture' to https://picsum.photos/id/169/200/300
//2. add a new class called picture to the element with id 'mainpicture'

//Implement a function called changeHTML to 
//1. change the innerHTML of the element with id 'demo' 
